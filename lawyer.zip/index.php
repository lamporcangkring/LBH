<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>LawyerApp - Manajemen Pengacara</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        [x-cloak] { display: none !important; }
        /* Smooth scrolling */
        html { scroll-behavior: smooth; }
        /* Hide scrollbar for clean mobile look */
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
    </style>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1e293b', // Slate 800
                        secondary: '#334155', // Slate 700
                        accent: '#2563eb', // Blue 600
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-gray-50 text-slate-800 font-sans antialiased" x-data="app()">

    <!-- LOGIN SCREEN -->
    <div x-show="!isLoggedIn" class="fixed inset-0 z-[100] bg-gray-100 flex items-center justify-center p-4">
        <div class="bg-white w-full max-w-md p-8 rounded-2xl shadow-xl">
            <div class="text-center mb-8">
                <div class="mb-4">
                    <img src="lawyer.jpg" alt="Logo" class="h-24 mx-auto rounded-full object-cover">
                </div>
                <h1 class="text-2xl font-bold text-slate-800">LawyerApp</h1>
                <p class="text-slate-500 text-sm">Sistem Manajemen Kantor Hukum</p>
            </div>

            <form @submit.prevent="login">
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Username</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400">
                            <i class="fas fa-user"></i>
                        </span>
                        <input type="text" x-model="loginForm.username" class="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none" placeholder="Username" required>
                    </div>
                </div>
                
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400">
                            <i class="fas fa-lock"></i>
                        </span>
                        <input type="password" x-model="loginForm.password" class="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none" placeholder="Password" required>
                    </div>
                </div>

                <div x-show="loginError" class="mb-4 p-3 bg-red-50 text-red-600 text-sm rounded-lg flex items-center">
                    <i class="fas fa-exclamation-circle mr-2"></i>
                    <span x-text="loginError"></span>
                </div>

                <button type="submit" class="w-full bg-primary text-white py-3 rounded-xl font-bold text-lg shadow-lg hover:bg-slate-700 transition">
                    <span x-show="!isLoading">Masuk</span>
                    <span x-show="isLoading"><i class="fas fa-spinner fa-spin"></i></span>
                </button>
            </form>

            <div class="mt-6 text-center text-xs text-gray-400">
                <p>Demo Credentials:</p>
                <p>Admin: admin / admin123</p>
                <p>Lawyer: lawyer1 / password123</p>
                <p>Client: client1 / client123</p>
            </div>
        </div>
    </div>

    <!-- MAIN APP (Only visible when logged in) -->
    <div x-show="isLoggedIn" x-cloak class="min-h-screen flex">
    
    <!-- DESKTOP SIDEBAR (Hidden on Mobile) -->
    <aside class="hidden md:flex flex-col w-64 h-screen fixed bg-primary text-white shadow-xl z-50">
        <div class="p-6 text-center border-b border-slate-700">
            <div class="flex justify-center mb-2">
                <img src="lawyer.jpg" alt="Logo" class="h-16 w-16 rounded-full object-cover">
            </div>
            <h1 class="text-2xl font-bold tracking-wider">LawyerApp</h1>
            <p class="text-xs text-slate-400 mt-1">Sistem Manajemen Hukum</p>
            <div class="mt-2 text-xs bg-slate-700 py-1 px-2 rounded inline-block uppercase tracking-wide" x-text="currentUser?.role"></div>
        </div>
        <nav class="flex-1 overflow-y-auto py-4">
            <a href="#" @click.prevent="setTab('home')" :class="tab === 'home' ? 'bg-slate-700 border-r-4 border-blue-500' : 'hover:bg-slate-700'" class="block px-6 py-3 transition-all">
                <i class="fas fa-home w-6 text-center"></i> Beranda
            </a>
            <a href="#" @click.prevent="setTab('tasks')" :class="tab === 'tasks' ? 'bg-slate-700 border-r-4 border-blue-500' : 'hover:bg-slate-700'" class="block px-6 py-3 transition-all">
                <i class="fas fa-tasks w-6 text-center"></i> Tugas & Sidang
            </a>
            <a href="#" @click.prevent="setTab('cases')" :class="tab === 'cases' ? 'bg-slate-700 border-r-4 border-blue-500' : 'hover:bg-slate-700'" class="block px-6 py-3 transition-all">
                <i class="fas fa-briefcase w-6 text-center"></i> Manajemen Kasus
            </a>
             <a href="#" @click.prevent="setTab('documents')" :class="tab === 'documents' ? 'bg-slate-700 border-r-4 border-blue-500' : 'hover:bg-slate-700'" class="block px-6 py-3 transition-all">
                <i class="fas fa-file-alt w-6 text-center"></i> Dokumentasi
            </a>
            <a href="#" @click.prevent="setTab('profile')" :class="tab === 'profile' ? 'bg-slate-700 border-r-4 border-blue-500' : 'hover:bg-slate-700'" class="block px-6 py-3 transition-all">
                <i class="fas fa-user-tie w-6 text-center"></i> Profil
            </a>
            <template x-if="currentUser && currentUser.role === 'admin'">
                <a href="#" @click.prevent="setTab('master')" :class="tab === 'master' ? 'bg-slate-700 border-r-4 border-blue-500' : 'hover:bg-slate-700'" class="block px-6 py-3 transition-all">
                    <i class="fas fa-database w-6 text-center"></i> Master Data
                </a>
            </template>
        </nav>
        <div class="p-4 border-t border-slate-700">
            <button @click="logout" class="w-full py-2 px-4 bg-red-600 hover:bg-red-700 rounded text-sm transition">Keluar</button>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="md:ml-64 min-h-screen pb-20 md:pb-0 transition-all duration-300 w-full">
        
        <!-- HEADER (Mobile & Desktop) -->
        <header class="bg-white shadow-sm sticky top-0 z-40 px-4 py-3 flex justify-between items-center">
            <div class="flex items-center">
                <!-- Mobile Logo -->
                <div class="md:hidden mr-2">
                    <img src="lawyer.jpg" alt="Logo" class="h-8 w-8 rounded-full object-cover">
                </div>
                <h2 class="text-xl font-semibold text-slate-800" x-text="pageTitle"></h2>
            </div>
            <div class="flex items-center space-x-3">
                <button class="p-2 rounded-full hover:bg-gray-100 relative">
                    <i class="fas fa-bell text-slate-600"></i>
                    <span class="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
                </button>
                <button class="p-2 rounded-full hover:bg-gray-100" @click="logout" title="Keluar">
                    <i class="fas fa-power-off text-red-500"></i>
                </button>
                <div class="w-8 h-8 rounded-full bg-slate-300 overflow-hidden border border-slate-400">
                    <img :src="currentUser && currentUser.avatar ? currentUser.avatar : ('https://ui-avatars.com/api/?name=' + (currentUser ? currentUser.full_name : 'User') + '&background=random')" alt="User">
                </div>
            </div>
        </header>

        <!-- CONTENT AREA -->
        <div class="p-4 md:p-8 max-w-7xl mx-auto">
            
            <!-- HOME / DASHBOARD TAB -->
            <div x-show="tab === 'home'" x-transition.opacity>
                <!-- Stats Cards -->
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                        <div class="text-slate-400 text-xs uppercase font-bold">Total Tugas</div>
                        <div class="text-2xl font-bold text-slate-800 mt-1" x-text="stats.total">0</div>
                    </div>
                    <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                        <div class="text-yellow-500 text-xs uppercase font-bold">Pending</div>
                        <div class="text-2xl font-bold text-slate-800 mt-1" x-text="stats.pending">0</div>
                    </div>
                    <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                        <div class="text-green-500 text-xs uppercase font-bold">Selesai</div>
                        <div class="text-2xl font-bold text-slate-800 mt-1" x-text="stats.completed">0</div>
                    </div>
                    <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                        <div class="text-blue-500 text-xs uppercase font-bold">Kasus Aktif</div>
                        <div class="text-2xl font-bold text-slate-800 mt-1" x-text="cases.filter(c => c.status === 'Open').length">0</div>
                    </div>
                </div>

                <!-- Upcoming Priority Tasks -->
                <h3 class="font-bold text-lg mb-3 flex items-center">
                    <i class="fas fa-fire text-red-500 mr-2"></i> Prioritas Tinggi
                </h3>
                <div class="space-y-3">
                    <template x-for="task in priorityTasks" :key="task.id">
                        <div class="bg-white p-4 rounded-xl shadow-sm border-l-4 border-red-500 flex justify-between items-center">
                            <div>
                                <div class="font-bold text-slate-800" x-text="task.title"></div>
                                <div class="text-sm text-slate-500 mt-1">
                                    <i class="far fa-calendar-alt mr-1"></i> <span x-text="formatDate(task.date)"></span>
                                    <span class="ml-2 px-2 py-0.5 rounded-full text-xs bg-slate-100 text-slate-600" x-text="task.type"></span>
                                </div>
                            </div>
                            <button @click="toggleTask(task.id)" class="w-8 h-8 rounded-full border-2 border-gray-300 flex items-center justify-center text-gray-300 hover:border-green-500 hover:text-green-500 transition">
                                <i class="fas fa-check"></i>
                            </button>
                        </div>
                    </template>
                    <div x-show="priorityTasks.length === 0" class="text-center py-8 text-slate-400 bg-white rounded-xl border border-dashed border-gray-300">
                        Tidak ada tugas prioritas tinggi.
                    </div>
                </div>
            </div>

            <!-- TASKS TAB -->
            <div x-show="tab === 'tasks'" x-transition.opacity x-cloak>
                <div class="flex justify-between items-center mb-4">
                    <div class="flex space-x-2 overflow-x-auto no-scrollbar pb-2">
                        <button @click="filter = 'all'" :class="filter === 'all' ? 'bg-primary text-white' : 'bg-white text-slate-600'" class="px-4 py-2 rounded-lg text-sm font-medium shadow-sm whitespace-nowrap">Semua</button>
                        <button @click="filter = 'pending'" :class="filter === 'pending' ? 'bg-primary text-white' : 'bg-white text-slate-600'" class="px-4 py-2 rounded-lg text-sm font-medium shadow-sm whitespace-nowrap">Belum Selesai</button>
                        <button @click="filter = 'completed'" :class="filter === 'completed' ? 'bg-primary text-white' : 'bg-white text-slate-600'" class="px-4 py-2 rounded-lg text-sm font-medium shadow-sm whitespace-nowrap">Selesai</button>
                    </div>
                </div>

                <div class="space-y-3 pb-20">
                    <template x-for="task in filteredTasks" :key="task.id">
                        <div class="bg-white p-4 rounded-xl shadow-sm flex justify-between items-start transition-all" :class="task.status === 'completed' ? 'opacity-60' : ''">
                            <div class="flex-1">
                                <div class="flex items-center mb-1">
                                    <span x-show="task.priority === 'Tinggi'" class="w-2 h-2 rounded-full bg-red-500 mr-2"></span>
                                    <span x-show="task.priority === 'Sedang'" class="w-2 h-2 rounded-full bg-yellow-500 mr-2"></span>
                                    <span x-show="task.priority === 'Rendah'" class="w-2 h-2 rounded-full bg-green-500 mr-2"></span>
                                    <h4 class="font-bold text-slate-800" :class="task.status === 'completed' ? 'line-through' : ''" x-text="task.title"></h4>
                                </div>
                                <div class="text-sm text-slate-500 flex flex-wrap gap-2">
                                    <span class="flex items-center"><i class="far fa-clock mr-1"></i> <span x-text="formatDate(task.date)"></span></span>
                                    <span class="bg-gray-100 px-2 rounded text-xs py-0.5" x-text="task.type"></span>
                                    <span x-show="task.case_id" class="bg-blue-100 text-blue-800 px-2 rounded text-xs py-0.5 flex items-center">
                                        <i class="fas fa-briefcase mr-1 text-[10px]"></i>
                                        <span x-text="getCaseName(task.case_id)"></span>
                                    </span>
                                </div>
                            </div>
                            <div class="flex flex-col space-y-2 ml-2">
                                <button @click="toggleTask(task.id)" class="text-gray-400 hover:text-green-600">
                                    <i :class="task.status === 'completed' ? 'fas fa-check-circle text-green-500 text-xl' : 'far fa-circle text-xl'"></i>
                                </button>
                                <button @click="deleteTask(task.id)" class="text-gray-300 hover:text-red-500">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </div>
                        </div>
                    </template>
                </div>
                
                <!-- Floating Action Button for Mobile -->
                <button @click="showAddModal = true" class="fixed bottom-20 right-4 md:bottom-8 md:right-8 bg-accent text-white w-14 h-14 rounded-full shadow-lg flex items-center justify-center text-2xl hover:bg-blue-700 transition transform hover:scale-105 z-30">
                    <i class="fas fa-plus"></i>
                </button>
            </div>

            <!-- CASES TAB -->
            <div x-show="tab === 'cases'" x-transition.opacity x-cloak>
                 <div class="flex justify-between items-center mb-6">
                    <h3 class="text-lg font-bold">Daftar Kasus</h3>
                    <button @click="showAddCaseModal = true" class="bg-primary text-white px-4 py-2 rounded-lg text-sm shadow hover:bg-slate-700 transition">
                        <i class="fas fa-plus mr-1"></i> Tambah Kasus
                    </button>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pb-20">
                    <template x-for="c in cases" :key="c.id">
                        <div class="bg-white p-5 rounded-xl shadow-sm border-l-4" :class="c.status === 'Open' ? 'border-green-500' : (c.status === 'On Hold' ? 'border-yellow-500' : 'border-gray-500')">
                            <div class="flex justify-between items-start">
                                <h4 class="font-bold text-lg text-slate-800" x-text="c.title"></h4>
                                <div class="relative" x-data="{ open: false }">
                                    <button @click="open = !open" class="text-gray-400 hover:text-gray-600"><i class="fas fa-ellipsis-v"></i></button>
                                    <div x-show="open" @click.outside="open = false" class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-20 border">
                                        <a href="#" @click.prevent="updateCaseStatus(c.id, 'Open'); open = false" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Set Status: Open</a>
                                        <a href="#" @click.prevent="updateCaseStatus(c.id, 'On Hold'); open = false" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Set Status: On Hold</a>
                                        <a href="#" @click.prevent="updateCaseStatus(c.id, 'Closed'); open = false" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Set Status: Closed</a>
                                        <div class="border-t border-gray-100 my-1"></div>
                                        <a href="#" @click.prevent="deleteCase(c.id); open = false" class="block px-4 py-2 text-sm text-red-600 hover:bg-gray-100">Hapus Kasus</a>
                                    </div>
                                </div>
                            </div>
                            <div class="text-sm text-slate-500 mt-1 mb-3">
                                <i class="fas fa-user mr-1"></i> <span x-text="c.client_name"></span>
                            </div>
                            <p class="text-sm text-gray-600 mb-4 line-clamp-2" x-text="c.description"></p>
                            <div class="flex items-center justify-between">
                                <span class="px-2 py-1 rounded text-xs font-semibold" 
                                    :class="c.status === 'Open' ? 'bg-green-100 text-green-700' : (c.status === 'On Hold' ? 'bg-yellow-100 text-yellow-700' : 'bg-gray-100 text-gray-700')"
                                    x-text="c.status"></span>
                                <button @click="viewCaseDetail(c)" class="text-accent text-sm font-medium hover:underline">Detail <i class="fas fa-arrow-right ml-1"></i></button>
                            </div>
                        </div>
                    </template>
                </div>
            </div>

            <!-- DOCUMENTS TAB -->
            <div x-show="tab === 'documents'" x-transition.opacity x-cloak>
                 <div class="flex justify-between items-center mb-6">
                    <h3 class="text-lg font-bold">Dokumentasi Hukum</h3>
                    <button @click="showAddDocModal = true" class="bg-primary text-white px-4 py-2 rounded-lg text-sm shadow hover:bg-slate-700 transition">
                        <i class="fas fa-upload mr-1"></i> Upload Dokumen
                    </button>
                </div>

                <div class="bg-white rounded-xl shadow-sm overflow-hidden hidden md:block">
                    <table class="w-full text-left text-sm text-gray-600">
                        <thead class="bg-gray-50 text-gray-800 font-bold uppercase text-xs border-b">
                            <tr>
                                <th class="px-6 py-4">Nama Dokumen</th>
                                <th class="px-6 py-4 hidden md:table-cell">Tipe</th>
                                <th class="px-6 py-4 hidden md:table-cell">Kasus Terkait</th>
                                <th class="px-6 py-4 hidden md:table-cell">Tanggal</th>
                                <th class="px-6 py-4 text-right">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <template x-for="doc in documents" :key="doc.id">
                                <tr class="hover:bg-gray-50 transition">
                                    <td class="px-6 py-4">
                                        <div class="flex items-center">
                                            <div class="w-8 h-8 rounded bg-blue-100 text-blue-600 flex items-center justify-center mr-3 text-lg">
                                                <i class="fas fa-file-alt"></i>
                                            </div>
                                            <div>
                                                <div class="font-bold text-gray-800" x-text="doc.title"></div>
                                                <div class="text-xs text-gray-500 md:hidden mt-1">
                                                    <span x-text="doc.type"></span> &bull; <span x-text="formatDate(doc.date)"></span>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 hidden md:table-cell">
                                        <span class="bg-gray-100 px-2 py-1 rounded text-xs" x-text="doc.type"></span>
                                    </td>
                                    <td class="px-6 py-4 hidden md:table-cell text-xs">
                                        <span x-text="getCaseName(doc.case_id)"></span>
                                    </td>
                                    <td class="px-6 py-4 hidden md:table-cell" x-text="formatDate(doc.date)"></td>
                                    <td class="px-6 py-4 text-right">
                                        <button class="text-gray-400 hover:text-blue-600 mr-2"><i class="fas fa-download"></i></button>
                                        <button @click="deleteDocument(doc.id)" class="text-gray-400 hover:text-red-600"><i class="fas fa-trash-alt"></i></button>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                     <div x-show="documents.length === 0" class="p-8 text-center text-gray-400">
                        Belum ada dokumen tersimpan.
                    </div>
                </div>
                <div class="md:hidden space-y-4">
                    <template x-for="c in cases" :key="c.id">
                        <div class="bg-white rounded-xl shadow-sm overflow-hidden">
                            <div class="px-4 py-3 bg-gray-50 font-semibold text-gray-800" x-text="c.title"></div>
                            <template x-if="documents.filter(d => d.case_id == c.id).length > 0">
                                <div class="divide-y">
                                    <template x-for="doc in documents.filter(d => d.case_id == c.id)" :key="doc.id">
                                        <div class="px-4 py-3 flex items-center justify-between">
                                            <div class="flex-1">
                                                <div class="font-medium text-gray-800" x-text="doc.title"></div>
                                                <div class="text-xs text-gray-500 mt-1">
                                                    <span x-text="doc.type"></span> • <span x-text="formatDate(doc.date)"></span>
                                                </div>
                                            </div>
                                            <div class="flex items-center gap-3 pl-3">
                                                <button class="text-gray-400 hover:text-blue-600"><i class="fas fa-download"></i></button>
                                                <button @click="deleteDocument(doc.id)" class="text-gray-400 hover:text-red-600"><i class="fas fa-trash-alt"></i></button>
                                            </div>
                                        </div>
                                    </template>
                                </div>
                            </template>
                            <div x-show="documents.filter(d => d.case_id == c.id).length === 0" class="px-4 py-4 text-gray-400 text-sm">
                                Belum ada dokumen untuk kasus ini.
                            </div>
                        </div>
                    </template>
                    <div class="bg-white rounded-xl shadow-sm overflow-hidden" x-show="documents.filter(d => !d.case_id).length > 0">
                        <div class="px-4 py-3 bg-gray-50 font-semibold text-gray-800">Umum</div>
                        <div class="divide-y">
                            <template x-for="doc in documents.filter(d => !d.case_id)" :key="doc.id">
                                <div class="px-4 py-3 flex items-center justify-between">
                                    <div class="flex-1">
                                        <div class="font-medium text-gray-800" x-text="doc.title"></div>
                                        <div class="text-xs text-gray-500 mt-1">
                                            <span x-text="doc.type"></span> • <span x-text="formatDate(doc.date)"></span>
                                        </div>
                                    </div>
                                    <div class="flex items-center gap-3 pl-3">
                                        <button class="text-gray-400 hover:text-blue-600"><i class="fas fa-download"></i></button>
                                        <button @click="deleteDocument(doc.id)" class="text-gray-400 hover:text-red-600"><i class="fas fa-trash-alt"></i></button>
                                    </div>
                                </div>
                            </template>
                        </div>
                    </div>
                </div>
            </div>

            <!-- MASTER DATA TAB (Admin only) -->
            <div x-show="tab === 'master'" x-transition.opacity x-cloak>
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div class="bg-white rounded-xl shadow-sm p-6">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-lg font-bold">Pengacara</h3>
                            <button @click="openAddUser('lawyer')" class="bg-primary text-white px-3 py-2 rounded-lg text-sm shadow hover:bg-slate-700 transition"><i class="fas fa-plus mr-1"></i> Tambah</button>
                        </div>
                        <div class="space-y-2">
                            <template x-for="u in users.filter(x => x.role === 'lawyer')" :key="u.id">
                                <div class="flex items-center justify-between p-3 rounded border">
                                    <div>
                                        <div class="font-bold" x-text="u.full_name"></div>
                                        <div class="text-xs text-gray-500" x-text="u.email"></div>
                                        <div class="text-xs text-gray-400" x-text="u.username"></div>
                                    </div>
                                    <div class="flex gap-2">
                                        <button @click="openEditUser(u)" class="text-gray-500 hover:text-blue-600"><i class="fas fa-edit"></i></button>
                                        <button @click="deleteUser(u.id)" class="text-gray-400 hover:text-red-600"><i class="fas fa-trash-alt"></i></button>
                                    </div>
                                </div>
                            </template>
                            <div x-show="users.filter(x => x.role === 'lawyer').length === 0" class="text-sm text-gray-400 italic">Belum ada data pengacara.</div>
                        </div>
                    </div>
                    <div class="bg-white rounded-xl shadow-sm p-6">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-lg font-bold">Klien</h3>
                            <button @click="openAddUser('client')" class="bg-primary text-white px-3 py-2 rounded-lg text-sm shadow hover:bg-slate-700 transition"><i class="fas fa-plus mr-1"></i> Tambah</button>
                        </div>
                        <div class="space-y-2">
                            <template x-for="u in users.filter(x => x.role === 'client')" :key="u.id">
                                <div class="flex items-center justify-between p-3 rounded border">
                                    <div>
                                        <div class="font-bold" x-text="u.full_name"></div>
                                        <div class="text-xs text-gray-500" x-text="u.email"></div>
                                        <div class="text-xs text-gray-400" x-text="u.username"></div>
                                    </div>
                                    <div class="flex gap-2">
                                        <button @click="openEditUser(u)" class="text-gray-500 hover:text-blue-600"><i class="fas fa-edit"></i></button>
                                        <button @click="deleteUser(u.id)" class="text-gray-400 hover:text-red-600"><i class="fas fa-trash-alt"></i></button>
                                    </div>
                                </div>
                            </template>
                            <div x-show="users.filter(x => x.role === 'client').length === 0" class="text-sm text-gray-400 italic">Belum ada data klien.</div>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-xl shadow-sm p-6 mt-6">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-bold">Pengadilan</h3>
                        <div class="flex gap-2">
                            <input type="text" x-model="newCourt" placeholder="Nama Pengadilan" class="px-3 py-2 border rounded-lg text-sm">
                            <button @click="addCourt(newCourt)" class="bg-primary text-white px-3 py-2 rounded-lg text-sm">Tambah</button>
                        </div>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-2">
                        <template x-for="c in courts" :key="c">
                            <div class="flex items-center justify-between p-3 rounded border">
                                <div class="flex items-center gap-2 w-full">
                                    <input x-show="editingCourt === c" type="text" x-model="editCourtName" class="flex-1 px-3 py-2 border rounded-lg text-sm">
                                    <span x-show="editingCourt !== c" class="flex-1" x-text="c"></span>
                                    <div class="flex gap-2">
                                        <button x-show="editingCourt !== c" @click="startEditCourt(c)" class="text-gray-500 hover:text-blue-600"><i class="fas fa-edit"></i></button>
                                        <button x-show="editingCourt === c" @click="renameCourt(c, editCourtName)" class="text-white bg-accent px-2 py-1 rounded text-xs">Simpan</button>
                                        <button x-show="editingCourt === c" @click="cancelEditCourt()" class="text-gray-500 px-2 py-1 rounded text-xs">Batal</button>
                                        <button @click="deleteCourt(c)" class="text-gray-400 hover:text-red-600"><i class="fas fa-trash-alt"></i></button>
                                    </div>
                                </div>
                            </div>
                        </template>
                    </div>
                </div>
            </div>
            
            <div x-show="showUserModal" class="fixed inset-0 z-[60] flex items-end md:items-center justify-center" x-cloak>
                <div class="absolute inset-0 bg-black bg-opacity-50 backdrop-blur-sm" @click="showUserModal = false"></div>
                <div class="bg-white w-full md:w-[500px] md:rounded-xl rounded-t-2xl p-6 relative transform transition-transform duration-300"
                     x-transition:enter="translate-y-full md:translate-y-10 opacity-0"
                     x-transition:enter-end="translate-y-0 opacity-100"
                     x-transition:leave="translate-y-full md:translate-y-10 opacity-0">
                    <div class="w-12 h-1.5 bg-gray-300 rounded-full mx-auto mb-6 md:hidden"></div>
                    <h3 class="text-xl font-bold mb-4" x-text="userForm.id ? 'Edit Pengguna' : 'Tambah Pengguna'"></h3>
                    <form @submit.prevent="saveUser">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Role</label>
                                <select x-model="userForm.role" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
                                    <option value="admin">Admin</option>
                                    <option value="lawyer">Pengacara</option>
                                    <option value="client">Klien</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Username</label>
                                <input type="text" x-model="userForm.username" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none" required>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Nama Lengkap</label>
                                <input type="text" x-model="userForm.full_name" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none" required>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                                <input type="email" x-model="userForm.email" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
                            </div>
                            <div class="md:col-span-2">
                                <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
                                <input type="password" x-model="userForm.password" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none" :required="!userForm.id">
                            </div>
                        </div>
                        <div class="mt-3 flex justify-end gap-2">
                            <button type="button" @click="showUserModal = false" class="px-4 py-2 bg-gray-100 text-slate-700 rounded-lg">Batal</button>
                            <button type="submit" class="px-4 py-2 bg-primary text-white rounded-lg">Simpan</button>
                        </div>
                    </form>
                    <button @click="showUserModal = false" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600 md:block hidden">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>
            </div>
             <!-- PROFILE TAB (Placeholder) -->
             <div x-show="tab === 'profile'" x-transition.opacity x-cloak>
                <div class="bg-white rounded-xl shadow-sm overflow-hidden">
                    <div class="h-24 bg-primary"></div>
                    <div class="px-6 relative">
                        <div class="w-24 h-24 rounded-full border-4 border-white bg-gray-200 absolute -top-12 overflow-hidden">
                            <img :src="currentUser && currentUser.avatar ? currentUser.avatar : ('https://ui-avatars.com/api/?name=' + (currentUser ? currentUser.full_name : 'User') + '&size=200')" alt="Profile">
                        </div>
                    </div>
                    <div class="pt-14 px-6 pb-6">
                        <h2 class="text-2xl font-bold" x-text="currentUser?.full_name"></h2>
                        <p class="text-gray-500 capitalize" x-text="currentUser?.role"></p>
                        
                        <div class="mt-6 space-y-3">
                            <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                <span class="text-gray-600">Mode Gelap</span>
                                <div class="w-10 h-6 bg-gray-300 rounded-full relative cursor-pointer">
                                    <div class="w-4 h-4 bg-white rounded-full absolute top-1 left-1"></div>
                                </div>
                            </div>
                            <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg cursor-pointer">
                                <span class="text-gray-600">Pengaturan Notifikasi</span>
                                <i class="fas fa-chevron-right text-gray-400"></i>
                            </div>
                            
                            <div class="p-4 bg-gray-50 rounded-lg">
                                <div class="font-bold text-slate-700 mb-2">Edit Profil</div>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-sm text-gray-600 mb-1">Nama Lengkap</label>
                                        <input type="text" x-model="profileForm.full_name" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
                                    </div>
                                    <div>
                                        <label class="block text-sm text-gray-600 mb-1">Email</label>
                                        <input type="email" x-model="profileForm.email" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
                                    </div>
                                    <div class="md:col-span-2">
                                        <label class="block text-sm text-gray-600 mb-1">Password (opsional)</label>
                                        <input type="password" x-model="profileForm.password" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none" placeholder="Isi untuk ganti password">
                                    </div>
                                </div>
                                <div class="mt-3 flex justify-end">
                                    <button @click="updateProfile" class="px-4 py-2 bg-primary text-white rounded-lg">Simpan Perubahan</button>
                                </div>
                            </div>

                            <div class="p-4 bg-gray-50 rounded-lg">
                                <div class="font-bold text-slate-700 mb-2">Foto Avatar</div>
                                <div class="flex items-center gap-4">
                                    <img class="w-16 h-16 rounded-full border" :src="avatarPreview || (currentUser && currentUser.avatar ? currentUser.avatar : ('https://ui-avatars.com/api/?name=' + (currentUser ? currentUser.full_name : 'User')))">
                                    <input type="file" accept="image/*" @change="onAvatarChange">
                                    <button @click="uploadAvatar" class="px-4 py-2 bg-accent text-white rounded-lg">Upload</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </main>

    <!-- MOBILE BOTTOM NAVIGATION -->
    <nav class="md:hidden fixed bottom-0 w-full bg-white border-t border-gray-200 flex justify-around py-2 z-50 safe-area-pb">
        <a href="#" @click.prevent="setTab('home')" class="flex flex-col items-center p-2 w-14 transition" :class="tab === 'home' ? 'text-accent' : 'text-slate-400'">
            <i class="fas fa-home text-xl mb-1"></i>
            <span class="text-[9px] font-medium">Beranda</span>
        </a>
        <a href="#" @click.prevent="setTab('tasks')" class="flex flex-col items-center p-2 w-14 transition" :class="tab === 'tasks' ? 'text-accent' : 'text-slate-400'">
            <i class="fas fa-tasks text-xl mb-1"></i>
            <span class="text-[9px] font-medium">Tugas</span>
        </a>
        <a href="#" @click.prevent="showAddModal = true" class="flex flex-col items-center justify-center -mt-6">
            <div class="w-12 h-12 bg-accent rounded-full shadow-lg flex items-center justify-center text-white text-xl">
                <i class="fas fa-plus"></i>
            </div>
        </a>
        <a href="#" @click.prevent="setTab('cases')" class="flex flex-col items-center p-2 w-14 transition" :class="tab === 'cases' ? 'text-accent' : 'text-slate-400'">
            <i class="fas fa-briefcase text-xl mb-1"></i>
            <span class="text-[9px] font-medium">Kasus</span>
        </a>
        <a href="#" @click.prevent="setTab('documents')" class="flex flex-col items-center p-2 w-14 transition" :class="tab === 'documents' ? 'text-accent' : 'text-slate-400'">
            <i class="fas fa-file-alt text-xl mb-1"></i>
            <span class="text-[9px] font-medium">Dokumen</span>
        </a>
    </nav>

    <!-- ADD TASK MODAL -->
    <div x-show="showAddModal" class="fixed inset-0 z-[60] flex items-end md:items-center justify-center" x-cloak>
        <div class="absolute inset-0 bg-black bg-opacity-50 backdrop-blur-sm" @click="showAddModal = false"></div>
        <div class="bg-white w-full md:w-[500px] md:rounded-xl rounded-t-2xl p-6 relative transform transition-transform duration-300" 
             x-transition:enter="translate-y-full md:translate-y-10 opacity-0"
             x-transition:enter-end="translate-y-0 opacity-100"
             x-transition:leave="translate-y-full md:translate-y-10 opacity-0">
            
            <div class="w-12 h-1.5 bg-gray-300 rounded-full mx-auto mb-6 md:hidden"></div>
            
            <h3 class="text-xl font-bold mb-4">Tambah Tugas Baru</h3>
            
            <form @submit.prevent="addTask">
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Judul Tugas</label>
                    <input type="text" x-model="newTask.title" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none" placeholder="Contoh: Sidang Kasus..." required>
                </div>
                
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Tanggal</label>
                        <input type="date" x-model="newTask.date" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none" required>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Tipe</label>
                        <select x-model="newTask.type" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
                            <option value="Sidang">Sidang</option>
                            <option value="Dokumen">Dokumen</option>
                            <option value="Pertemuan">Pertemuan</option>
                            <option value="Riset">Riset</option>
                        </select>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tautkan ke Kasus (Opsional)</label>
                    <select x-model="newTask.case_id" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
                        <option value="">- Pilih Kasus -</option>
                        <template x-for="c in cases" :key="c.id">
                            <option :value="c.id" x-text="c.title"></option>
                        </template>
                    </select>
                </div>

                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Prioritas</label>
                    <div class="flex space-x-2">
                        <button type="button" @click="newTask.priority = 'Tinggi'" :class="newTask.priority === 'Tinggi' ? 'bg-red-100 border-red-500 text-red-700' : 'bg-white border-gray-200 text-gray-600'" class="flex-1 py-2 border rounded-lg text-sm font-medium transition">Tinggi</button>
                        <button type="button" @click="newTask.priority = 'Sedang'" :class="newTask.priority === 'Sedang' ? 'bg-yellow-100 border-yellow-500 text-yellow-700' : 'bg-white border-gray-200 text-gray-600'" class="flex-1 py-2 border rounded-lg text-sm font-medium transition">Sedang</button>
                        <button type="button" @click="newTask.priority = 'Rendah'" :class="newTask.priority === 'Rendah' ? 'bg-green-100 border-green-500 text-green-700' : 'bg-white border-gray-200 text-gray-600'" class="flex-1 py-2 border rounded-lg text-sm font-medium transition">Rendah</button>
                    </div>
                </div>

                <button type="submit" class="w-full bg-accent text-white py-3 rounded-xl font-bold text-lg shadow-lg hover:bg-blue-700 transition">Simpan Tugas</button>
            </form>
            
            <button @click="showAddModal = false" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600 md:block hidden">
                <i class="fas fa-times text-xl"></i>
            </button>
        </div>
    </div>

    <!-- ADD CASE MODAL -->
    <div x-show="showAddCaseModal" class="fixed inset-0 z-[60] flex items-end md:items-center justify-center" x-cloak>
        <div class="absolute inset-0 bg-black bg-opacity-50 backdrop-blur-sm" @click="showAddCaseModal = false"></div>
        <div class="bg-white w-full md:w-[500px] md:rounded-xl rounded-t-2xl p-6 relative transform transition-transform duration-300"
             x-transition:enter="translate-y-full md:translate-y-10 opacity-0"
             x-transition:enter-end="translate-y-0 opacity-100"
             x-transition:leave="translate-y-full md:translate-y-10 opacity-0">
             
            <h3 class="text-xl font-bold mb-4">Buat Kasus Baru</h3>
            <form @submit.prevent="addCase">
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Nama Kasus</label>
                    <input type="text" x-model="newCase.title" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none" required>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Nama Klien</label>
                    <input type="text" x-model="newCase.client_name" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none" required>
                </div>
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Pengadilan</label>
                        <div class="flex gap-2">
                            <select x-model="newCase.court" class="flex-1 px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
                                <option value="">- Pilih Pengadilan -</option>
                                <template x-for="c in courts" :key="c">
                                    <option :value="c" x-text="c"></option>
                                </template>
                            </select>
                            <button type="button" @click="promptAddCourt()" class="px-3 py-2 bg-accent text-white rounded-lg text-sm">Tambah</button>
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Nomor Perkara</label>
                        <div class="flex gap-2">
                            <input list="caseNumbers" type="text" x-model="newCase.case_number" class="flex-1 px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none" placeholder="123/Pdt.G/2025/...">
                            <datalist id="caseNumbers">
                                <template x-for="n in case_numbers" :key="n">
                                    <option :value="n" x-text="n"></option>
                                </template>
                            </datalist>
                            <button type="button" @click="addCaseNumber(newCase.case_number)" class="px-3 py-2 bg-accent text-white rounded-lg text-sm">Simpan ke Master</button>
                        </div>
                    </div>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Tanggal Mulai</label>
                    <div class="flex gap-2">
                        <input list="startDates" type="date" x-model="newCase.start_date" class="flex-1 px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
                        <datalist id="startDates">
                            <template x-for="d in start_dates" :key="d">
                                <option :value="d" x-text="d"></option>
                            </template>
                        </datalist>
                        <button type="button" @click="addStartDate(newCase.start_date)" class="px-3 py-2 bg-accent text-white rounded-lg text-sm">Simpan ke Master</button>
                    </div>
                </div>
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Deskripsi Singkat</label>
                    <textarea x-model="newCase.description" rows="3" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"></textarea>
                </div>
                <button type="submit" class="w-full bg-primary text-white py-3 rounded-xl font-bold text-lg shadow-lg hover:bg-slate-700 transition">Simpan Kasus</button>
            </form>
            <button @click="showAddCaseModal = false" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600 md:block hidden"><i class="fas fa-times text-xl"></i></button>
        </div>
    </div>

    <!-- ADD DOCUMENT MODAL -->
    <div x-show="showAddDocModal" class="fixed inset-0 z-[60] flex items-end md:items-center justify-center" x-cloak>
        <div class="absolute inset-0 bg-black bg-opacity-50 backdrop-blur-sm" @click="showAddDocModal = false"></div>
        <div class="bg-white w-full md:w-[500px] md:rounded-xl rounded-t-2xl p-6 relative transform transition-transform duration-300"
             x-transition:enter="translate-y-full md:translate-y-10 opacity-0"
             x-transition:enter-end="translate-y-0 opacity-100"
             x-transition:leave="translate-y-full md:translate-y-10 opacity-0">
             
            <h3 class="text-xl font-bold mb-4">Upload Dokumen</h3>
            <form @submit.prevent="addDocument">
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Nama Dokumen</label>
                    <input type="text" x-model="newDoc.title" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none" placeholder="example.pdf" required>
                </div>
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Tipe</label>
                        <select x-model="newDoc.type" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
                            <option value="Kontrak">Kontrak</option>
                            <option value="Gugatan">Gugatan</option>
                            <option value="Bukti">Bukti</option>
                            <option value="Surat">Surat</option>
                            <option value="BAP">BAP</option>
                            <option value="Lainnya">Lainnya</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Tanggal</label>
                        <input type="date" x-model="newDoc.date" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none" required>
                    </div>
                </div>
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Terkait Kasus</label>
                    <select x-model="newDoc.case_id" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none" required>
                        <option value="">- Pilih Kasus -</option>
                        <template x-for="c in cases" :key="c.id">
                            <option :value="c.id" x-text="c.title"></option>
                        </template>
                    </select>
                </div>
                <button type="submit" class="w-full bg-primary text-white py-3 rounded-xl font-bold text-lg shadow-lg hover:bg-slate-700 transition">Simpan Dokumen</button>
            </form>
            <button @click="showAddDocModal = false" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600 md:block hidden"><i class="fas fa-times text-xl"></i></button>
        </div>
    </div>

    <!-- DETAIL CASE MODAL -->
    <div x-show="showDetailCaseModal" class="fixed inset-0 z-[60] flex items-end md:items-center justify-center" x-cloak>
        <div class="absolute inset-0 bg-black bg-opacity-50 backdrop-blur-sm" @click="showDetailCaseModal = false"></div>
        <div class="bg-white w-full md:w-[600px] md:max-h-[90vh] md:rounded-xl rounded-t-2xl p-6 relative transform transition-transform duration-300 overflow-y-auto"
             x-transition:enter="translate-y-full md:translate-y-10 opacity-0"
             x-transition:enter-end="translate-y-0 opacity-100"
             x-transition:leave="translate-y-full md:translate-y-10 opacity-0">
             
            <template x-if="selectedCase">
                <div>
                    <div class="flex justify-between items-start mb-4">
                        <div>
                            <span class="px-2 py-1 rounded text-xs font-semibold mb-2 inline-block" 
                                  :class="selectedCase.status === 'Open' ? 'bg-green-100 text-green-700' : (selectedCase.status === 'On Hold' ? 'bg-yellow-100 text-yellow-700' : 'bg-gray-100 text-gray-700')"
                                  x-text="selectedCase.status"></span>
                            <h3 class="text-xl font-bold text-slate-800" x-text="selectedCase.title"></h3>
                            <div class="text-sm text-slate-500 mt-1">
                                <i class="fas fa-user mr-1"></i> <span x-text="selectedCase.client_name"></span>
                            </div>
                        </div>
                        <button @click="showDetailCaseModal = false" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times text-xl"></i></button>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 text-sm">
                        <div class="bg-gray-50 p-3 rounded-lg">
                            <div class="text-gray-500">Pengadilan</div>
                            <div class="font-medium text-gray-800" x-text="selectedCase.court || '-'"></div>
                        </div>
                        <div class="bg-gray-50 p-3 rounded-lg">
                            <div class="text-gray-500">No. Perkara</div>
                            <div class="font-medium text-gray-800" x-text="selectedCase.case_number || '-'"></div>
                        </div>
                        <div class="bg-gray-50 p-3 rounded-lg">
                            <div class="text-gray-500">Mulai</div>
                            <div class="font-medium text-gray-800" x-text="selectedCase.start_date || '-'"></div>
                        </div>
                    </div>

                    <div class="mb-6">
                        <h4 class="font-bold text-sm text-gray-700 uppercase mb-2">Penugasan Pengacara</h4>
                        <div class="flex items-center gap-3">
                            <span class="text-sm text-gray-600">Ditugaskan ke:</span>
                            <span class="px-2 py-1 rounded bg-blue-50 text-blue-700 text-xs" x-text="getUserName(selectedCase.assigned_to) || 'Belum ditugaskan'"></span>
                        </div>
                        <div class="mt-3" x-show="currentUser && (currentUser.role === 'admin' || currentUser.role === 'lawyer')">
                            <label class="block text-xs text-gray-500 mb-1">Ganti Penugasan</label>
                            <div class="flex gap-2">
                                <select x-model="assignForm.user_id" class="flex-1 px-3 py-2 border rounded-lg text-sm">
                                    <option value="">- Pilih Pengacara -</option>
                                    <template x-for="u in lawyerUsers" :key="u.id">
                                        <option :value="u.id" x-text="u.full_name"></option>
                                    </template>
                                </select>
                                <button @click="assignCase(selectedCase.id, assignForm.user_id)" class="px-3 py-2 bg-primary text-white rounded-lg text-sm">Simpan</button>
                            </div>
                        </div>
                    </div>

                    <div class="mb-6">
                        <h4 class="font-bold text-sm text-gray-700 uppercase mb-2">Deskripsi</h4>
                        <p class="text-gray-600 text-sm leading-relaxed" x-text="selectedCase.description || 'Tidak ada deskripsi.'"></p>
                    </div>

                    <div class="mb-6">
                        <h4 class="font-bold text-sm text-gray-700 uppercase mb-2">Timeline Kasus</h4>
                        <div class="space-y-2">
                            <template x-for="t in (selectedCase.timeline || [])" :key="t.date + t.activity">
                                <div class="flex items-start gap-3 bg-gray-50 p-3 rounded-lg border border-gray-100">
                                    <div class="w-2 h-2 rounded-full bg-blue-500 mt-2"></div>
                                    <div>
                                        <div class="text-sm font-medium text-gray-800" x-text="t.activity"></div>
                                        <div class="text-xs text-gray-500" x-text="formatDate(t.date) + ' • ' + (t.by || '-')"></div>
                                    </div>
                                </div>
                            </template>
                            <div x-show="!selectedCase.timeline || selectedCase.timeline.length === 0" class="text-sm text-gray-400 italic">Belum ada aktivitas.</div>
                        </div>
                        <div class="mt-3" x-show="currentUser && (currentUser.role === 'admin' || currentUser.role === 'lawyer')">
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-2">
                                <input type="date" x-model="timelineForm.date" class="px-3 py-2 border rounded-lg text-sm">
                                <input type="text" x-model="timelineForm.activity" placeholder="Aktivitas..." class="md:col-span-2 px-3 py-2 border rounded-lg text-sm">
                            </div>
                            <button @click="addTimeline(selectedCase.id)" class="mt-2 px-3 py-2 bg-accent text-white rounded-lg text-sm">Tambah Aktivitas</button>
                        </div>
                    </div>

                    <div class="mb-6">
                        <h4 class="font-bold text-sm text-gray-700 uppercase mb-2">Dokumen Terkait</h4>
                        <div class="space-y-2">
                            <template x-for="doc in documents.filter(d => d.case_id == selectedCase.id)" :key="doc.id">
                                <div class="flex items-center justify-between bg-gray-50 p-3 rounded-lg border border-gray-100">
                                    <div class="flex items-center">
                                        <i class="fas fa-file-alt text-blue-500 mr-3"></i>
                                        <div>
                                            <div class="text-sm font-medium text-gray-800" x-text="doc.title"></div>
                                            <div class="text-xs text-gray-500" x-text="doc.type + ' • ' + formatDate(doc.date)"></div>
                                        </div>
                                    </div>
                                    <button class="text-gray-400 hover:text-blue-600"><i class="fas fa-download"></i></button>
                                </div>
                            </template>
                            <div x-show="documents.filter(d => d.case_id == selectedCase.id).length === 0" class="text-sm text-gray-400 italic">
                                Belum ada dokumen.
                            </div>
                        </div>
                    </div>

                    <div>
                        <h4 class="font-bold text-sm text-gray-700 uppercase mb-2">Tugas & Agenda</h4>
                        <div class="space-y-2">
                            <template x-for="task in tasks.filter(t => t.case_id == selectedCase.id)" :key="task.id">
                                <div class="flex items-center justify-between bg-gray-50 p-3 rounded-lg border border-gray-100">
                                    <div class="flex items-center">
                                        <div class="w-2 h-2 rounded-full mr-3" :class="task.status === 'completed' ? 'bg-green-500' : 'bg-yellow-500'"></div>
                                        <div>
                                            <div class="text-sm font-medium text-gray-800" :class="task.status === 'completed' ? 'line-through text-gray-500' : ''" x-text="task.title"></div>
                                            <div class="text-xs text-gray-500" x-text="formatDate(task.date) + ' • ' + task.type"></div>
                                        </div>
                                    </div>
                                </div>
                            </template>
                            <div x-show="tasks.filter(t => t.case_id == selectedCase.id).length === 0" class="text-sm text-gray-400 italic">
                                Belum ada tugas terkait.
                            </div>
                        </div>
                    </div>
                </div>
            </template>
        </div>
    </div>
    
    <!-- End of Main App Div -->
    </div>

    <script>
        // Force register the new "killer" service worker to overwrite the old one
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('sw.js?v=' + new Date().getTime()).then(function(registration) {
                registration.update();
            }).catch(function(error) {
                console.log('SW registration failed: ', error);
            });
        }

        function app() {
            return {
                isLoggedIn: false,
                currentUser: null,
                isLoading: false,
                loginError: '',
                loginForm: { username: '', password: '' },
                profileForm: { full_name: '', email: '', password: '' },
                avatarFile: null,
                avatarPreview: '',

                tab: 'home',
                filter: 'all',
                showAddModal: false,
                showAddCaseModal: false,
                showAddDocModal: false,
                showDetailCaseModal: false,
                selectedCase: null,
                stats: { total: 0, pending: 0, completed: 0 },
                tasks: [],
                cases: [],
                documents: [],
                newTask: {
                    title: '',
                    date: new Date().toISOString().split('T')[0],
                    priority: 'Sedang',
                    type: 'Sidang',
                    status: 'pending',
                    case_id: ''
                },
                newCase: {
                    title: '',
                    client_name: '',
                    status: 'Open',
                    description: '',
                    court: '',
                    case_number: '',
                    start_date: new Date().toISOString().split('T')[0]
                },
                newDoc: {
                    title: '',
                    type: 'Kontrak',
                    date: new Date().toISOString().split('T')[0],
                    case_id: ''
                },
                users: [],
                courts: [],
                case_numbers: [],
                start_dates: [],
                assignForm: { user_id: '' },
                timelineForm: { date: new Date().toISOString().split('T')[0], activity: '' },
                newCourt: '',
                editingCourt: null,
                editCourtName: '',
                showUserModal: false,
                userForm: { id: null, role: 'lawyer', username: '', full_name: '', email: '', password: '' },
                
                init() {
                    const savedUser = localStorage.getItem('lawyerAppUser');
                    if (savedUser) {
                        this.currentUser = JSON.parse(savedUser);
                        this.isLoggedIn = true;
                        this.fetchData();
                        this.profileForm = { full_name: this.currentUser.full_name || '', email: this.currentUser.email || '', password: '' };
                    }
                },

                async login() {
                    this.isLoading = true;
                    this.loginError = '';
                    
                    try {
                        const res = await fetch('api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ 
                                action: 'login', 
                                username: this.loginForm.username, 
                                password: this.loginForm.password 
                            })
                        });
                        const result = await res.json();
                        
                        if (result.success) {
                            this.currentUser = result.user;
                            this.isLoggedIn = true;
                            localStorage.setItem('lawyerAppUser', JSON.stringify(result.user));
                            this.fetchData();
                            this.loginForm = { username: '', password: '' };
                        } else {
                            this.loginError = result.message;
                        }
                    } catch (e) {
                        this.loginError = 'Terjadi kesalahan koneksi';
                        console.error(e);
                    } finally {
                        this.isLoading = false;
                    }
                },

                 logout() {
                     this.isLoggedIn = false;
                     this.currentUser = null;
                     this.tab = 'home';
                     localStorage.removeItem('lawyerAppUser');
                 },

                 async updateProfile() {
                     if (!this.currentUser) return;
                     try {
                         const res = await fetch('api.php', {
                             method: 'POST',
                             headers: { 'Content-Type': 'application/json' },
                             body: JSON.stringify({ 
                                 action: 'update_profile', 
                                 id: this.currentUser.id, 
                                 full_name: this.profileForm.full_name, 
                                 email: this.profileForm.email, 
                                 password: this.profileForm.password 
                             })
                         });
                         const result = await res.json();
                         if (result.success) {
                             const updatedUser = (result.data.users || []).find(u => u.id == this.currentUser.id) || this.currentUser;
                             this.currentUser = updatedUser;
                             localStorage.setItem('lawyerAppUser', JSON.stringify(this.currentUser));
                             this.profileForm.password = '';
                         }
                     } catch (e) { console.error(e); }
                 },

                 onAvatarChange(e) {
                     const file = e.target.files[0];
                     if (!file) return;
                     this.avatarFile = file;
                     this.avatarPreview = URL.createObjectURL(file);
                 },

                 async uploadAvatar() {
                     if (!this.avatarFile || !this.currentUser) return;
                     const fd = new FormData();
                     fd.append('action', 'upload_avatar');
                     fd.append('user_id', this.currentUser.id);
                     fd.append('avatar', this.avatarFile);
                     try {
                         const res = await fetch('api.php', { method: 'POST', body: fd });
                         const result = await res.json();
                         if (result.success) {
                             const updatedUser = (result.data.users || []).find(u => u.id == this.currentUser.id) || this.currentUser;
                             this.currentUser = updatedUser;
                             localStorage.setItem('lawyerAppUser', JSON.stringify(this.currentUser));
                             this.avatarPreview = '';
                             this.avatarFile = null;
                         }
                     } catch (e) { console.error(e); }
                 },
                get pageTitle() {
                    const titles = {
                        'home': 'Dashboard',
                        'tasks': 'Daftar Tugas',
                        'cases': 'Manajemen Kasus',
                        'documents': 'Dokumentasi',
                        'clients': 'Manajemen Klien',
                        'profile': 'Profil Saya'
                    };
                    return titles[this.tab];
                },

                get filteredTasks() {
                    if (this.filter === 'all') return this.tasks;
                    return this.tasks.filter(t => t.status === this.filter);
                },

                get priorityTasks() {
                    return this.tasks.filter(t => t.priority === 'Tinggi' && t.status === 'pending');
                },

                get lawyerUsers() {
                    return (this.users || []).filter(u => u.role === 'lawyer');
                },

                openAddUser(role) {
                    this.userForm = { id: null, role, username: '', full_name: '', email: '', password: '' };
                    this.showUserModal = true;
                },
                openEditUser(u) {
                    this.userForm = { id: u.id, role: u.role, username: u.username, full_name: u.full_name, email: u.email, password: '' };
                    this.showUserModal = true;
                },
                async saveUser() {
                    const action = this.userForm.id ? 'update_user' : 'create_user';
                    try {
                        const res = await fetch('api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action, user: this.userForm })
                        });
                        const result = await res.json();
                        if (result.success) {
                            this.updateLocalData(result.data);
                            this.showUserModal = false;
                        }
                    } catch (e) { console.error(e); }
                },
                async deleteUser(id) {
                    if (!confirm('Hapus user ini?')) return;
                    try {
                        const res = await fetch('api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'delete_user', id })
                        });
                        const result = await res.json();
                        if (result.success) this.updateLocalData(result.data);
                    } catch (e) { console.error(e); }
                },
                async addCourt(name) {
                    if (!name) return;
                    try {
                        const res = await fetch('api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'add_court', name })
                        });
                        const result = await res.json();
                        if (result.success) {
                            this.updateLocalData(result.data);
                            this.newCourt = '';
                        }
                    } catch (e) { console.error(e); }
                },
                async deleteCourt(name) {
                    if (!confirm('Hapus pengadilan ini?')) return;
                    try {
                        const res = await fetch('api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'delete_court', name })
                        });
                        const result = await res.json();
                        if (result.success) this.updateLocalData(result.data);
                    } catch (e) { console.error(e); }
                },
                startEditCourt(name) {
                    this.editingCourt = name;
                    this.editCourtName = name;
                },
                cancelEditCourt() {
                    this.editingCourt = null;
                    this.editCourtName = '';
                },
                async renameCourt(oldName, newName) {
                    const name = (newName || '').trim();
                    if (!name || name === oldName) { this.cancelEditCourt(); return; }
                    try {
                        const res = await fetch('api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'rename_court', old_name: oldName, new_name: name })
                        });
                        const result = await res.json();
                        if (result.success) {
                            this.updateLocalData(result.data);
                            this.cancelEditCourt();
                        }
                    } catch (e) { console.error(e); }
                },
 
                setTab(val) {
                    this.tab = val;
                    // Reset Modals
                    this.showAddModal = false;
                    this.showAddCaseModal = false;
                    this.showAddDocModal = false;
                    this.showDetailCaseModal = false;
                    this.showUserModal = false;
                },

                viewCaseDetail(c) {
                    console.log('Opening case detail:', c);
                    this.selectedCase = c;
                    this.assignForm.user_id = c.assigned_to || '';
                    this.timelineForm = { date: new Date().toISOString().split('T')[0], activity: '' };
                    this.showDetailCaseModal = true;
                },

                getCaseName(id) {
                    const c = (this.cases || []).find(x => x.id == id);
                    return c ? c.title : 'Umum';
                },
                
                getUserName(id) {
                    const u = (this.users || []).find(x => x.id == id);
                    return u ? u.full_name : '';
                },

                async fetchData() {
                    try {
                        const res = await fetch('api.php?t=' + new Date().getTime());
                        const data = await res.json();
                        this.tasks = data.tasks || [];
                        this.cases = data.cases || [];
                        this.documents = data.documents || [];
                        this.stats = data.stats || { total: 0, pending: 0, completed: 0 };
                        this.users = data.users || [];
                        this.courts = data.courts || [];
                        this.case_numbers = data.case_numbers || [];
                        this.start_dates = data.start_dates || [];
                    } catch (e) {
                        console.error("Error fetching data", e);
                    }
                },

                async addTask() {
                    if (!this.newTask.title) return;
                    
                    try {
                        const res = await fetch('api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'add', task: this.newTask })
                        });
                        const result = await res.json();
                        if (result.success) {
                            this.updateLocalData(result.data);
                            this.showAddModal = false;
                            this.resetForm();
                            this.setTab('tasks');
                        }
                    } catch (e) {
                        alert('Gagal menyimpan tugas');
                    }
                },

                async addCase() {
                    if (!this.newCase.title) return;
                    try {
                        const res = await fetch('api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'add_case', case: this.newCase })
                        });
                        const result = await res.json();
                        if (result.success) {
                            this.updateLocalData(result.data);
                            this.showAddCaseModal = false;
                            this.newCase = { title: '', client_name: '', status: 'Open', description: '', court: '', case_number: '', start_date: new Date().toISOString().split('T')[0] };
                        }
                    } catch (e) { alert('Gagal menyimpan kasus'); }
                },

                async addDocument() {
                    if (!this.newDoc.title) return;
                    try {
                        const res = await fetch('api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'add_document', document: this.newDoc })
                        });
                        const result = await res.json();
                        if (result.success) {
                            this.updateLocalData(result.data);
                            this.showAddDocModal = false;
                            this.newDoc = { title: '', type: 'Kontrak', date: new Date().toISOString().split('T')[0], case_id: '' };
                        }
                    } catch (e) { alert('Gagal menyimpan dokumen'); }
                },

                async toggleTask(id) {
                    try {
                        const res = await fetch('api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'toggle', id: id })
                        });
                        const result = await res.json();
                        if (result.success) this.updateLocalData(result.data);
                    } catch (e) { console.error(e); }
                },

                async deleteTask(id) {
                    if(!confirm('Hapus tugas ini?')) return;
                    try {
                        const res = await fetch('api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'delete', id: id })
                        });
                        const result = await res.json();
                        if (result.success) this.updateLocalData(result.data);
                    } catch (e) { console.error(e); }
                },

                async deleteCase(id) {
                    if(!confirm('Hapus kasus ini beserta datanya?')) return;
                    try {
                        const res = await fetch('api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'delete_case', id: id })
                        });
                        const result = await res.json();
                        if (result.success) this.updateLocalData(result.data);
                    } catch (e) { console.error(e); }
                },

                async deleteDocument(id) {
                    if(!confirm('Hapus dokumen ini?')) return;
                    try {
                        const res = await fetch('api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'delete_document', id: id })
                        });
                        const result = await res.json();
                        if (result.success) this.updateLocalData(result.data);
                    } catch (e) { console.error(e); }
                },

                async updateCaseStatus(id, status) {
                    try {
                        const res = await fetch('api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'update_case_status', id: id, status: status })
                        });
                        const result = await res.json();
                        if (result.success) this.updateLocalData(result.data);
                    } catch (e) { console.error(e); }
                },

                async promptAddCourt() {
                    const name = prompt('Nama Pengadilan');
                    if (!name) return;
                    try {
                        const res = await fetch('api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'add_court', name })
                        });
                        const result = await res.json();
                        if (result.success) {
                            this.updateLocalData(result.data);
                            this.newCase.court = name;
                        }
                    } catch (e) { console.error(e); }
                },

                async addCaseNumber(val) {
                    if (!val) return;
                    try {
                        const res = await fetch('api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'add_case_number', value: val })
                        });
                        const result = await res.json();
                        if (result.success) this.updateLocalData(result.data);
                    } catch (e) { console.error(e); }
                },

                async addStartDate(date) {
                    if (!date) return;
                    try {
                        const res = await fetch('api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'add_start_date', date })
                        });
                        const result = await res.json();
                        if (result.success) this.updateLocalData(result.data);
                    } catch (e) { console.error(e); }
                },

                async addTimeline(caseId) {
                    if (!this.timelineForm.activity) return;
                    try {
                        const res = await fetch('api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ 
                                action: 'add_case_timeline', 
                                id: caseId, 
                                entry: { 
                                    date: this.timelineForm.date, 
                                    activity: this.timelineForm.activity, 
                                    by: this.currentUser ? this.currentUser.full_name : 'system' 
                                } 
                            })
                        });
                        const result = await res.json();
                        if (result.success) {
                            this.updateLocalData(result.data);
                            this.selectedCase = (result.data.cases || []).find(c => c.id == caseId) || this.selectedCase;
                            this.timelineForm.activity = '';
                        }
                    } catch (e) { console.error(e); }
                },

                async assignCase(caseId, userId) {
                    try {
                        const res = await fetch('api.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ action: 'assign_case', id: caseId, user_id: userId })
                        });
                        const result = await res.json();
                        if (result.success) {
                            this.updateLocalData(result.data);
                            this.selectedCase = (result.data.cases || []).find(c => c.id == caseId) || this.selectedCase;
                        }
                    } catch (e) { console.error(e); }
                },

                updateLocalData(data) {
                    this.tasks = data.tasks || [];
                    this.cases = data.cases || [];
                    this.documents = data.documents || [];
                    this.stats = data.stats || { total: 0, pending: 0, completed: 0 };
                    this.users = data.users || [];
                    this.courts = data.courts || [];
                    this.case_numbers = data.case_numbers || [];
                    this.start_dates = data.start_dates || [];
                },

                resetForm() {
                    this.newTask = {
                        title: '',
                        date: new Date().toISOString().split('T')[0],
                        priority: 'Sedang',
                        type: 'Sidang',
                        status: 'pending',
                        case_id: ''
                    };
                },

                formatDate(dateString) {
                    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    return new Date(dateString).toLocaleDateString('id-ID', options);
                }
            }
        }
    </script>
</body>
</html>
